package directspecials_package;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class Userprofile {
	
	String expected = null;
	String actual = null;
	WebDriver driver;
	WebDriverWait wait;
	String appURL = "https://www.directv.com/DTVAPP/register/register.jsp";
	//Locators
		private By byAccountNumber = By.id("accountNumber");
		private By byPhoneNumber = By.id("phoneNumber");
		private By byLastDigits = By.id("ccn4");
		private By byLastName = By.id("lastName");
		private By bySubmit = By.linkText("Continue");
		private By byError = By.id("header-register");
		
		
@BeforeTest

  public void uprofile()
  
  {
	  
	  	driver = new FirefoxDriver();
	  	driver.get("https://www.directspecials.com/");
	  	driver.manage().window().maximize();
	  	wait = new WebDriverWait(driver, 5);
	  	driver.findElement(By.linkText("Existing Customer?")).click();
		driver.findElement(By.linkText("Click Here")).click();
		driver.findElement(By.xpath("/html/body/div[4]/div[2]/div/div[3]/div[1]/div[1]/div/div/div/div/div[1]/form/div[3]/fieldset/div[2]/div[8]/a")).click();
  }
		
@Test(dataProvider = "userInfo")

public void UserDetails (String acntno, String phnum,String ccn,String lname) {
	
	driver.navigate().to(appURL);
	//driver.findElement(byAccountNumber).clear();
	driver.findElement(byAccountNumber).sendKeys(acntno);
	//driver.findElement(byPhoneNumber).clear();
	driver.findElement(byPhoneNumber).sendKeys(phnum);
	//driver.findElement(byLastDigits).clear();
	driver.findElement(byLastDigits).sendKeys(ccn);
	//driver.findElement(byLastName).clear();
	driver.findElement(byLastName).sendKeys(lname);
	wait.until(ExpectedConditions.visibilityOfElementLocated(bySubmit));
	driver.findElement(bySubmit).click();
	
	  //Check for error message
	  		wait.until(ExpectedConditions.presenceOfElementLocated(byError));
	  		String actual = driver.findElement(byError).getText();
	  		String expected = "Create a directv.com account.";
	  		Assert.assertEquals(expected, actual);
		
		}
	    
	    @DataProvider(name="userInfo")
		public Object[][] UserInformation() {
			Object[][] arrayObject = getExcelData("D:/WorkingScripts/Scripts/UserProfile/userdetails.xls","Sheet1");
			return arrayObject;
		}

		/**
		 * @param File Name
		 * @param Sheet Name
		 * @return
		 */
		public String[][] getExcelData(String fileName, String sheetName) {
			String[][] arrayExcelData = null;
			try {
				FileInputStream fs = new FileInputStream(fileName);
				Workbook wb = Workbook.getWorkbook(fs);
				Sheet sh = wb.getSheet(sheetName);

				int totalNoOfCols = sh.getColumns();
				int totalNoOfRows = sh.getRows();
				
				arrayExcelData = new String[totalNoOfRows-1][totalNoOfCols];
				
				for (int i= 1 ; i < totalNoOfRows; i++) {

					for (int j=0; j < totalNoOfCols; j++) {
						arrayExcelData[i-1][j] = sh.getCell(j, i).getContents();
					}

				}
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
				e.printStackTrace();
			} catch (BiffException e) {
				e.printStackTrace();
			}
			return arrayExcelData;
		}

	    
 @AfterTest
  public void terminate(){
	    driver.quit();
 }
 
 
}
	    



	  



