package directspecials_package;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;


public class UserOptions {
	
	WebDriver driver;
		
@BeforeClass
	public void Deals()
	
	{
		
	driver = new FirefoxDriver();
	driver.get("https://www.directspecials.com/");
	driver.manage().window().maximize();
	
	}
@Test(priority=0) 

public void DirectTvLinks () {
	driver.findElement(By.linkText("DIRECTV DEALS")).click();
	driver.findElement(By.linkText("DIRECTV CHANNEL GUIDE")).click();
	driver.findElement(By.linkText("DIRECTV INTERNET")).click();
	driver.findElement(By.linkText("DIRECTV ON DEMAND")).click();
	driver.findElement(By.linkText("DIRECTV SPORTS")).click();
	driver.findElement(By.linkText("DIRECTV PACKAGES")).click();
}

@Test(priority=1)

public void DirectTvAdvs() {
	
	driver.findElement(By.xpath("/html/body/div[1]/div[1]/ul/li[1]/a/img")).click();
	driver.findElement(By.xpath("/html/body/div[1]/ul/li[1]/a")).click();
	driver.findElement(By.xpath("/html/body/div[1]/div[1]/ul/li[1]/a/img")).click();
	driver.findElement(By.xpath("/html/body/div[1]/ul/li[2]/a"));
	driver.findElement(By.xpath("/html/body/div[1]/div[1]/ul/li[1]/a/img")).click();
	driver.findElement(By.xpath("/html/body/div[1]/ul/li[3]/a")).click();
	driver.findElement(By.xpath("/html/body/div[1]/div[1]/ul/li[1]/a/img")).click();
	driver.findElement(By.xpath("/html/body/div[1]/ul/li[4]/a")).click();
	driver.findElement(By.xpath("/html/body/div[1]/div[1]/ul/li[1]/a/img")).click();
	driver.findElement(By.xpath("/html/body/div[1]/ul/li[5]/a")).click();
	driver.findElement(By.xpath("/html/body/div[1]/div[1]/ul/li[1]/a/img")).click();
	driver.findElement(By.xpath("/html/body/div[1]/ul/li[6]/a")).click();
	
}

@AfterTest 

	public void terminate()
{
    driver.quit();
}
}





