package directspecials_package;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
//import org.testng.annotations.AfterTest;
//import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import org.testng.annotations.Parameters;
//import java.util.concurrent.TimeUnit;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.testng.annotations.BeforeTest;
import org.openqa.selenium.ie.InternetExplorerDriver;
//import org.openqa.selenium.support.ui.WebDriverWait;

public class DiffBrowsers_UserOptions {
	
	WebDriver driver;
@Test	
@Parameters("browser")
public void setup(String browser) throws Exception{
    //Check if parameter passed from TestNG is 'firefox'
    if(browser.equalsIgnoreCase("firefox")){
  	  //create firefox instance
        driver = new FirefoxDriver();
        driver.manage().window().maximize();
		
    }
    //Check if parameter passed as 'chrome'
    else if(browser.equalsIgnoreCase("chrome")){
        //set path to chromedriver.exe You may need to download it from http://code.google.com/p/selenium/wiki/ChromeDriver
        System.setProperty("webdriver.chrome.driver","D:\\WorkingScripts\\Resources\\chromedriver.exe");
        //create chrome instance
        driver = new ChromeDriver();
        driver.manage().window().maximize();
		
    }
else if(browser.equalsIgnoreCase("IE")){
        //set path to IEdriver.exe You may need to download it from
 // 32 bits http://selenium-release.storage.googleapis.com/2.42/IEDriverServer_Win32_2.42.0.zip
 // 64 bits http://selenium-release.storage.googleapis.com/2.42/IEDriverServer_x64_2.42.0.zip
		System.setProperty("webdriver.ie.driver","D:\\WorkingScripts\\Resources\\IEDriverServer.exe");
        //create chrome instance
        driver = new InternetExplorerDriver();
        driver.manage().window().maximize();
		
    }
//@Test(priority=0) 

//public void DirectTvLinks () {
	driver.findElement(By.linkText("DIRECTV DEALS")).click();
	driver.findElement(By.linkText("DIRECTV CHANNEL GUIDE")).click();
	driver.findElement(By.linkText("DIRECTV INTERNET")).click();
	driver.findElement(By.linkText("DIRECTV ON DEMAND")).click();
	driver.findElement(By.linkText("DIRECTV SPORTS")).click();
	driver.findElement(By.linkText("DIRECTV PACKAGES")).click();
//}

//@Test(priority=1)

//public void DirectTvAdvs() {
	
	driver.findElement(By.xpath("/html/body/div[1]/div[1]/ul/li[1]/a/img")).click();
	driver.findElement(By.xpath("/html/body/div[1]/ul/li[1]/a")).click();
	driver.findElement(By.xpath("/html/body/div[1]/div[1]/ul/li[1]/a/img")).click();
	driver.findElement(By.xpath("/html/body/div[1]/ul/li[2]/a"));
	driver.findElement(By.xpath("/html/body/div[1]/div[1]/ul/li[1]/a/img")).click();
	driver.findElement(By.xpath("/html/body/div[1]/ul/li[3]/a")).click();
	driver.findElement(By.xpath("/html/body/div[1]/div[1]/ul/li[1]/a/img")).click();
	driver.findElement(By.xpath("/html/body/div[1]/ul/li[4]/a")).click();
	driver.findElement(By.xpath("/html/body/div[1]/div[1]/ul/li[1]/a/img")).click();
	driver.findElement(By.xpath("/html/body/div[1]/ul/li[5]/a")).click();
	driver.findElement(By.xpath("/html/body/div[1]/div[1]/ul/li[1]/a/img")).click();
	driver.findElement(By.xpath("/html/body/div[1]/ul/li[6]/a")).click();
	
//}

//@AfterTest 

	//public void terminate()
//{
    driver.quit();
}
}






