package directspecials_package;

import java.io.FileInputStream;
import java.io.IOException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;



public class DataDriven {
	public WebDriver driver;
	public WebDriverWait wait;
	String appURL = "https://www.directspecials.com/";
	
	//Locators
	private By byFname = By.id("FirstName");
	private By byLname = By.id("LastName");
	private By byPhone = By.id("Phone1");
	private By byAltphone = By.id("Phone2");
	private By byZip = By.id("ZipCode");
	
	@BeforeClass

		public void testSetup() {
		
			driver=new FirefoxDriver();
			driver.manage().window().maximize();
			wait = new WebDriverWait(driver, 5);
	}
	
	@Test(dataProvider="homePage")
	public void UserDetails(String firstName, String lastName,String callone,String calltwo,String zip) {
		driver.navigate().to(appURL);
		driver.findElement(byFname).clear();
		driver.findElement(byFname).sendKeys(firstName);
		driver.findElement(byLname).clear();
		driver.findElement(byLname).sendKeys(lastName);
		driver.findElement(byPhone).clear();
		driver.findElement(byPhone).sendKeys(callone);
		driver.findElement(byAltphone).clear();
		driver.findElement(byAltphone).sendKeys(calltwo);
		driver.findElement(byZip).clear();
		driver.findElement(byZip).sendKeys(zip);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div/div[3]/div[2]/div/div/div/form/button")));
		driver.findElement(By.xpath("/html/body/div/div[3]/div[2]/div/div/div/form/button")).click();
		driver.findElement(By.xpath("/html/body/div[2]/ul/li[1]/a")).click();
	}
	
	@DataProvider(name="homePage")
	public Object[][] loginData() throws BiffException, IOException {
		Object[][] arrayObject = getExcelData("D:/Interview_Project/dataDrvn.xls","Sheet1");
		return arrayObject;
	}

	/**
	 * @param File Name
	 * @param Sheet Name
	 * @return
	 * @throws IOException 
	 * @throws BiffException 
	 */
	public String[][] getExcelData(String fileName, String sheetName) throws BiffException, IOException {
		String[][] arrayExcelData = null;
		 {
			FileInputStream fs = new FileInputStream(fileName);
			Workbook wb = Workbook.getWorkbook(fs);
			Sheet sh = wb.getSheet(sheetName);

			int totalNoOfCols = sh.getColumns();
			int totalNoOfRows = sh.getRows();
			
			arrayExcelData = new String[totalNoOfRows-1][totalNoOfCols];
			
			for (int i= 1 ; i < totalNoOfRows; i++) {

				for (int j=0; j < totalNoOfCols; j++) {
					arrayExcelData[i-1][j] = sh.getCell(j, i).getContents();
				}

			}
		} 
		return arrayExcelData;
	}
@AfterTest

	public void tearDown() {
		driver.quit();
	}
}